export * from './settings-routing.module';
export * from './settings.module';
export * from './pages';
export *  from './components';