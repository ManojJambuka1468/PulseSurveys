import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-surveys',
  templateUrl: './surveys.component.html'
})
export class SurveysComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
