import { Component } from '@angular/core';
import { AuthService } from 'src/app/core/authentication/auth.service';

@Component({
  selector: 'app-pulse-surveys',
  templateUrl: './pulse-surveys.component.html',
  styles: [
  ]
})
export class PulseSurveysComponent {
  title = 'Pulse Surveys';
  isLoggedIn:boolean=false;
  constructor( private authService:AuthService){}
  ngOnInit(): void {
    this.isLoggedIn=this.authService.isAuthenticated();
  }

  login(){
    this.authService.login();
  }
  logout(){
    this.authService.logout();
  }
  token(){
    console.log(this.authService.token());
  }
}
