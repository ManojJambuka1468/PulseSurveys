import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PulseSurveysRoutingModule } from './pulse-surveys-routing.module';
import { PulseSurveysComponent } from './pages/pulse-surveys/pulse-surveys.component';


@NgModule({
  declarations: [
    PulseSurveysComponent
  ],
  imports: [
    CommonModule,
    PulseSurveysRoutingModule
  ]
})
export class PulseSurveysModule { }
