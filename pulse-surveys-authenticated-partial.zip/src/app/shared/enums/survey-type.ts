export enum surveyType{
    anonymous=0,
    known=1,
}