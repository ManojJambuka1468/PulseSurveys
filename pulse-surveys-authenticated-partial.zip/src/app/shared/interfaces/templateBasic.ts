export interface TemplateBasic{
    id?: string,
    description?:string,
    title: string 
}