export  interface selectOption{
    id:string ,
    text?:string
}
