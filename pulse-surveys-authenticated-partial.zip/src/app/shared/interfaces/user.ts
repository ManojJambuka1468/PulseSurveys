export interface  user{
    id?:string,
    name:string,
    email:string,
    imageUrl:string,
}