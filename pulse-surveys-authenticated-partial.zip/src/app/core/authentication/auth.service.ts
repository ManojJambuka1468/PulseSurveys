import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { JwksValidationHandler } from 'angular-oauth2-oidc-jwks';
import { user } from 'src/app/shared/interfaces/user';
import { authConfig } from './auth.config';

@Injectable()
export class AuthService {
  constructor(private oauthService: OAuthService, private http: HttpClient ){
    this.configureSingleSignOn();
  }
  User!:user;
  configureSingleSignOn() {
    this.oauthService.configure(authConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.setStorage(localStorage);
  //   this.oauthService.loadDiscoveryDocumentAndLogin().then(
  //     (isLoggedIn) => {
  //         if (isLoggedIn) {
  //           console.log('hello from logedIN');
  //           this.getUserbyId();
  //           this.oauthService.redirectUri='https://localhost:4200';
  //           this.oauthService.setupAutomaticSilentRefresh();
  //         } else {
  //           console.log('hello from else logedIN');
  //             this.oauthService.initCodeFlow();
  //         }
  //     },
  //     (error) => {
  //         if (error.status === 400) {
  //             location.reload();
  //         }
  //     }
  // );
  }

  login() {
    this.oauthService.initCodeFlow();
  }

  logout() {
    this.oauthService.logOut();
  }

  getUserbyId(){
    const getUserbyIdUrl='https://localhost:7000/api/user';
    const header = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.oauthService.getAccessToken()}`,
    });

    return this.http.get<user>(`${getUserbyIdUrl}/${this.getId()}`,{headers:header});
  }

  token() {
    console.log(this.oauthService.getIdentityClaims());
    return this.oauthService.getAccessToken();
  }
  getId(){
    // return this.oauthService.();
    return "79d0f962-f0e1-476f-994a-51d2e6931438";
  }

  isAuthenticated(): boolean {
    console.log('isAuthenicated',this.oauthService.hasValidIdToken());
    return this.oauthService.hasValidAccessToken();
  }
}
