import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, switchMap } from 'rxjs';
import { newSurvey, survey} from 'src/app/shared/interfaces/survey';
import { question } from 'src/app/shared/interfaces/question';
@Injectable({
  providedIn: 'root'
})
export class SurveysDataService {
  private surveysbaseUrl="https://6423e7c047401740432e5a4e.mockapi.io/surveys";
  constructor(private http:HttpClient) { }
  userId:string='DADA9B74-BADA-ED11-91BB-F4939FF3EA10';
  activeSurveys:BehaviorSubject<survey[]>=new BehaviorSubject<survey[]>([]);
  closedSurveys:BehaviorSubject<survey[]>=new BehaviorSubject<survey[]>([]);

  fetchSurveys(){ //
    return this.http.get<survey[]>(this.surveysbaseUrl);
  }
  updateSubject(data:survey[]){ //
    this.activeSurveys.next(data);
  }
  getSurveys(){ //
    return this.activeSurveys;
  }

  fetchActiveSurveys(){
    const activeSurveysUrl='https://localhost:7251/api/admin/surveys/active';
    return this.http.get<survey[]>(activeSurveysUrl);
  }
  updateActiveSubject(data:survey[]){
    this.activeSurveys.next(data);
  }
  getActiveSurveys(){
    return this.activeSurveys;
  }
  
  fetchClosedSurveys(){
    const closedSurveysUrl='https://localhost:7251/api/admin/surveys/closed';
    return this.http.get<survey[]>(closedSurveysUrl);
  }
  updateClosedSubject(data:survey[]){
    this.closedSurveys.next(data);
  }
  getClosedSurveys(){
    return this.closedSurveys;
  }

  getSurveyDetailById(surveyId:string){
    const surveyDetailsUrl='https://localhost:7251/api/me/surveys';
    return this.http.get<survey>(surveyDetailsUrl+'/'+surveyId);
  }
  
  getViewSurveyDetails(surveyId:string){
    const surveyDetailsUrl='https://localhost:7251/api/admin/surveys';
    return this.http.get<survey>(surveyDetailsUrl+'/'+surveyId);
  }


  updateSurveyDetails(surveyId:string,surveyDetails:survey){
    const updateSurveyDetailsUrl='https://localhost:7251/api/admin/surveys';
    return this.http.put<survey>(updateSurveyDetailsUrl+'/'+surveyId+'/'+this.userId,surveyDetails);
  }
  
  relaunchSurvey(surveyId:string,surveyDetails:survey){
    const relaunchSurveyUrl='https://localhost:7251/api/admin/surveys';
    return this.http.post<survey>(relaunchSurveyUrl+'/'+surveyId+'/relaunch/'+this.userId,surveyDetails);
  }

  getSurveyQuestions(surveyId:string){
    const surveyQuestionsUrl='https://localhost:7251/api/me/surveys';
    return this.http.get<question[]>(surveyQuestionsUrl+'/'+surveyId+'/questions');
  }

  

  AddNewSurvey(newSurvey:newSurvey){
    const AddNewSurvey='https://localhost:7251/api/templates';
    return this.http.post<newSurvey>(AddNewSurvey,newSurvey);
  }

  deleteTemplate(templateId:string){
    return this.http.delete(this.surveysbaseUrl+'/'+templateId);
  }

  closeSurvey(surveyId:string){
    const closeSurveyUrl='https://localhost:7251/api/admin/surveys';
    return this.http.patch(closeSurveyUrl+'/'+surveyId+'/close/'+this.userId,null);
  }
}
