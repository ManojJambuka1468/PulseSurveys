import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { user } from 'src/app/shared/interfaces/user';
import { response } from 'src/app/shared/interfaces/response';
import { survey } from 'src/app/shared/interfaces/survey';
import { AuthService } from '../authentication/auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http:HttpClient, private authService:AuthService) { }

  userId:string='24854ca3-34cd-ed11-bab1-c4cbe11934b8';
  User!:user;

  surveys:BehaviorSubject<survey[]>=new BehaviorSubject<survey[]>([]);
  completedSurveys:BehaviorSubject<survey[]>=new BehaviorSubject<survey[]>([]);
  
  getUserId(){
    return this.userId;
  }
  
  fetchOpenSurveys(){
    const token=this.authService.token();
    const header = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    });
    const activeSurveysUrl='https://localhost:7000/api/me/surveys/open';
    return this.http.get<survey[]>(activeSurveysUrl,{headers:header});
  }
  updateSubject(data:survey[]){
    this.surveys.next(data);
  }
  getOpenSurveys(){
    return this.surveys;
  }
  
  fetchCompletedSurveys(){
    const completedSurveysUrl='https://localhost:7251/api/me/surveys/completed';
    return this.http.get<survey[]>(completedSurveysUrl+'/'+this.userId);
  }
  
  updateCompletedSubject(data:survey[]){
    this.completedSurveys.next(data);
  }
  getCompletedSurveys(){
    return this.completedSurveys;
  }
  submitSurvey(surveyResponse:response[]){
    const submitSurveysUrl='https://localhost:7251/api/surveys/responses';
    return this.http.post<response[]>(submitSurveysUrl,surveyResponse);
  }
  
  getUserbyId(){
    const getUserbyIdUrl='https://localhost:7000/api/user';
    const header = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.authService.token()}`,
    });

    this.http.get<user>(`${getUserbyIdUrl}${this.authService.getId()}`,{headers:header}).subscribe((data)=>{
      this.User=data;
      console.log(data);
    });
  }

}
