import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { questionResponse } from 'src/app/shared/interfaces/question';
@Injectable({
  providedIn: 'root'
})
export class QuestionsService {

  constructor(private http:HttpClient) { }
  private questionsbaseUrl="https://6423e7c047401740432e5a4e.mockapi.io/questions";
  
  getSurveyQuestions(id:string){
    return this.http.get<questionResponse[]>(this.questionsbaseUrl);
  }

  getSurveyResponses(id:string){
    const surveyResponsesUrl ='https://localhost:7251/api/surveys'
    return this.http.get<questionResponse[]>(surveyResponsesUrl+'/'+id+'/responses');
  }
  getQuestionResponses(surveyId:string, questionId:string){
    const questionResponsesUrl ='https://localhost:7251/api/surveys'
    return this.http.get<questionResponse>(questionResponsesUrl+'/'+surveyId+'/responses/'+questionId);
  }
}
