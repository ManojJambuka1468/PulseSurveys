import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/authentication/auth.service';
import { user } from 'src/app/shared/interfaces/user';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent implements OnInit{
  currentUser!:user;
  constructor(private auth:AuthService){}
  ngOnInit(): void {
    this.auth.getUserbyId().subscribe((data)=>{
      this.currentUser=data
      console.log(this.currentUser,'from header');
    });
  }
  userName:string='Manoj Jambuka';
  currentDate:Date=new Date();
}
