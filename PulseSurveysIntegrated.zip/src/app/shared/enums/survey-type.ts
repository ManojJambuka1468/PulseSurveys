export enum surveyType{
    known=1,
    anonymous=0,
}