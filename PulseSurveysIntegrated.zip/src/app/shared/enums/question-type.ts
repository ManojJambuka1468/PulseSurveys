export enum questionType{
    Comment,
    Rating,
    Option
}
