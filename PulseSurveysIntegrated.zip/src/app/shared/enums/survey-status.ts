export enum surveyStatus{
    Active=1,
    Closed=0
}