import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { question } from 'src/app/shared/interfaces/question';
import { template } from 'src/app/shared/interfaces/template';
import { TemplateBasic } from 'src/app/shared/interfaces/templateBasic';

@Injectable({
  providedIn: 'root'
})
export class TemplatesDataService {
  private templatesBaseUrl="https://localhost:7251/api/templates";
  userId:string='DADA9B74-BADA-ED11-91BB-F4939FF3EA10';
  constructor(private http:HttpClient) { }
  templates:BehaviorSubject<template[]>=new BehaviorSubject<template[]>([]);

  fetchTemplates(){
    return this.http.get<template[]>(this.templatesBaseUrl);
  }
  updateTemplatesSubject(data:template[]){
    this.templates.next(data);
  }
  getTemplates(){ 
    return this.templates;
  }
  getTemplateLookUp(){
    const templatesLookUpUrl='https://localhost:7251/api/templates/lookup';
    return this.http.get<TemplateBasic[]>(templatesLookUpUrl);
  }
  
  getTemplateDetailsById(id:string){
    const templateBaseUrl='https://localhost:7251/api/templates';
    return this.http.get<template>(templateBaseUrl+'/'+id);
  }
  
  getTemplateQuestions(id:string){
    const templateBaseUrl='https://localhost:7251/api/templates';
    return this.http.get<question[]>(templateBaseUrl+'/'+id+'/questions');
  }
  updateTemplate(id:string,updatedTemplate:template){
    const updateTemplateUrl='https://localhost:7251/api/templates';
    return this.http.put<template>(updateTemplateUrl+'/'+id,updatedTemplate);
  }
  deleteTemplate(id:string){
    const deleteTemplateUrl='https://localhost:7251/api/templates';
    return this.http.delete(deleteTemplateUrl+'/'+id+'/'+this.userId);
  }
}
