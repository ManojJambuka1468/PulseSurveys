import { Injectable } from '@angular/core';
import { navItem } from 'src/app';

@Injectable({
  providedIn: 'root'
})
export class NavItemDataService {

  private leftNavList: navItem[]=[
    {
      title:'Me',
      slug:'me',
      icon:'ki-user'
    },
    {
      title:'Admin',
      slug:'admin',
      icon:'ki-user-duo'
    }
  ];
  getLeftNavList(){
    return this.leftNavList;
  }
}
