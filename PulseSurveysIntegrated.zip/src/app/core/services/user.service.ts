import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { response } from 'src/app/shared/interfaces/response';
import { survey } from 'src/app/shared/interfaces/survey';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http:HttpClient) { }

  userId:string='24854ca3-34cd-ed11-bab1-c4cbe11934b8';

  surveys:BehaviorSubject<survey[]>=new BehaviorSubject<survey[]>([]);
  completedSurveys:BehaviorSubject<survey[]>=new BehaviorSubject<survey[]>([]);
  
  getUserId(){
    return this.userId;
  }

  fetchOpenSurveys(){
    const activeSurveysUrl='https://localhost:7251/api/me/surveys/open';
    return this.http.get<survey[]>(activeSurveysUrl+'/'+this.userId);
  }
  updateSubject(data:survey[]){
    this.surveys.next(data);
  }
  getOpenSurveys(){
    return this.surveys;
  }
  
  fetchCompletedSurveys(){
    const completedSurveysUrl='https://localhost:7251/api/me/surveys/completed';
    return this.http.get<survey[]>(completedSurveysUrl+'/'+this.userId);
  }
  
  updateCompletedSubject(data:survey[]){
    this.completedSurveys.next(data);
  }
  getCompletedSurveys(){
    return this.completedSurveys;
  }
  submitSurvey(surveyResponse:response[]){
    const submitSurveysUrl='https://localhost:7251/api/surveys/responses';
    return this.http.post<response[]>(submitSurveysUrl,surveyResponse);
  }

}
