import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from './admin-routing.module';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { AgGridModule } from 'ag-grid-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { AdminComponent } from './pages';
import { ActionsDropdownGridChildComponent, CreateSurveyDetailsComponent, CreateSurveyQuestionsComponent, StepperWizardComponent, UpdateSurveyDetailsComponent } from './shared/components';
@NgModule({
  declarations: [
    AdminComponent,
    ActionsDropdownGridChildComponent,
    UpdateSurveyDetailsComponent,
    StepperWizardComponent,
    CreateSurveyDetailsComponent,
    CreateSurveyQuestionsComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    BsDropdownModule,
    AgGridModule,
    ReactiveFormsModule,
    FormsModule,
    AccordionModule.forRoot()
  ]
})
export class AdminModule { }
