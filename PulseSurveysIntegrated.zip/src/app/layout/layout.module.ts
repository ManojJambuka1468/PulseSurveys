import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HeaderComponent, LeftNavComponent } from '.';
import { RouterModule} from '@angular/router';


@NgModule({
  declarations: [
    LeftNavComponent,
    HeaderComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports:[
    LeftNavComponent,HeaderComponent
  ]
})
export class LayoutModule { }
